import { showView } from "./util.js";

const detailSection = document.querySelector('#movie-example');

export function detailPage() {
    showView(detailSection);
}