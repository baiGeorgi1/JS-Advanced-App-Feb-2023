import { showView } from "./util.js";

const createSection = document.querySelector('#add-movie');

export function createPage() {
    showView(createSection);
}