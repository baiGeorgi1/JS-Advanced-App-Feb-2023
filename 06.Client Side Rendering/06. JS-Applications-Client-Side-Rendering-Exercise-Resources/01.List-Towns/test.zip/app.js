import { html, render } from '../node_modules/lit-html/lit-html.js';

document.getElementById('btnLoadTowns').addEventListener('click', getTowns);


function getTowns(e) {
    e.preventDefault();

    const root = document.getElementById('root');
    const towns = document.getElementById('towns').value.split(', ');;
    const ul = document.createElement('ul');
    if (document.getElementById('towns').value) {
        towns.map(el => {
            let li = document.createElement('li');
            li.textContent = el;
            ul.appendChild(li);
        });
        root.appendChild(ul);
        document.getElementById('towns').value = '';

    }
}