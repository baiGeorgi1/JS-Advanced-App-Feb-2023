const url = 'http://localhost:3030/jsonstore/collections/books';
const loadBtn = document.getElementById('loadBooks');
loadBtn.addEventListener('click', loadBooksFunc);
let tBody = document.querySelector('tbody');
const formElement = document.querySelector('form button');
formElement.addEventListener('click', submitFunc);
const form = document.querySelector('form');
const formData = new FormData(form);

function submitFunc(e) {
    e.preventDefault();
    const bookName = formData.get('title');
    const bookAuthor = formData.get('author');
    if (bookAuthor.value == '' || bookName.value == '') {
        alert('All fields must be filled!');
    } else {
        fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ author: bookAuthor, title: bookName })
        })
            .then(res => res.json());
        form.reset();
    }
}

function loadBooksFunc() {
    fetch(url)
        .then(res => {
            if (!res.ok) {
                throw new Error(`HTTP request error! Status: ${res.status}!`);
            }
            return res.json();
        })
        .then(data => {
            Object.values(data).forEach((book) => {
                const tr = generateElem('tr');
                generateElem('td', `${book.title}`, tr);
                generateElem('td', `${book.author}`, tr);
                const td = generateElem('td', '', tr);
                const editBtn = generateElem('button', 'Edit', td);
                editBtn.addEventListener('click', editFunc);
                const deleteBtn = generateElem('button', 'Delete', td);
                deleteBtn.addEventListener('click', deleteFunc);
                tBody.appendChild(tr);
                function deleteFunc(event) {
                    const parent = event.target.parentElement.parentElement;
                    deleteUrl = `http://localhost:3030/jsonstore/collections/books/${book._id} `;
                    fetch(deleteUrl, {
                        method: 'DELETE'
                    })
                        .then(response => response.json());
                    parent.remove();
                }
                function editFunc(e) {
                    //     const parent = e.target.parentElement.parentElement;
                    //     const getUrl = `http://localhost:3030/jsonstore/collections/books/${book._id} `;
                    //     fetch(getUrl)
                    //         .then(res => res.json())
                    //         .then(data => {
                    //             formElement.removeEventListener('click', submitFunc);
                    //             formData.set('title', `${data.title}`);
                    //             formData.set('author', `${data.author}`);
                    //             form[0].value = data.title;
                    //             form[1].value = data.author;
                    //             form.childNodes[1].textContent = 'Edit FORM';
                    //             form.childNodes[11].textContent = 'Save';
                    //             console.log(form.childNodes);
                    //             formElement.addEventListener('click', saveFunc);
                    //         });

                }
            });
        });
}
// function saveFunc(e) {
//     e.preventDefault();
//     const bookName = formData.get('title');
//     const bookAuthor = formData.get('author');
//     if (bookAuthor == '' || bookName == '') {
//         alert('All fields must be filled!');
//     } else {
//         fetch(url, {
//             method: 'PUT',
//             headers: { 'Content-Type': 'application/json' },
//             body: JSON.stringify({ author: bookAuthor, title: bookName })
//         })
//             .then(res => res.json());
//         form.reset();
//     }
// }


function generateElem(type, text, parent, atribute) {
    const result = document.createElement(type);
    result.textContent = text;
    if (atribute) {
        for (const key in atribute) {
            result.setAttribute(key, atribute[key]);
        }
    }
    if (parent) {
        parent.appendChild(result);
    }
    return result;
}