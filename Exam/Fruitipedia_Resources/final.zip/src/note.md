## cotent

### Home Page (static , optional) [ok]

### Catatlog [ok]

    - like a home page or make new

### Details [ok]

[ok] - Create - Edit
[ok] - Delete (in delete btn => @click="${onDelete}" href="javascript:void(0)")

### Create [ok]

-- make create page

- addhandler
- create onSubmit async func
  -on html put oncreate func (@submit=${oncreate})

### Edit [ok]

-- make edit page

### Login [ok]

-- make login page

### Register [ok]

-- make reg page

### Bonus: []

    - Likes
    - Apply for job
    - Pagination
    - Search
    - Comments
    - Profile Page
    - Custom catalog

## Architecture

    - App enrty point (initialize libraries and modules,dispach nav)
    - Request module
    - User session
    - Data CRUD
    - Views
    - Util
